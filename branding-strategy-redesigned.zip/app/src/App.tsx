import React, { useState } from 'react';
import { BrandSystem } from './types/brand';
import { PRESET_BRANDS } from './data/presets';
import { HeroIdeaInput } from './components/HeroIdeaInput';
import { NeatBrandDashboard } from './components/NeatBrandDashboard';
import { ExportModal } from './components/modals/ExportModal';
import { NewBrandModal } from './components/modals/NewBrandModal';
import {
  Download,
  Lock,
  Unlock,
  ChevronDown,
} from 'lucide-react';

export const App: React.FC = () => {
  const [currentBrand, setCurrentBrand] = useState<BrandSystem>(PRESET_BRANDS[0]);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isNewBrandOpen, setIsNewBrandOpen] = useState(false);

  const handleProposeIdea = (idea: { title: string; problem: string; audience: string; category: string }) => {
    const brandId = idea.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const customBrand: BrandSystem = {
      ...PRESET_BRANDS[0],
      id: brandId,
      name: idea.title,
      industry: idea.category,
      stage1Discover: {
        ...PRESET_BRANDS[0].stage1Discover,
        problem: {
          value: idea.problem,
          source: 'user_provided',
          confidence: 'high',
          rationale: 'Supplied directly in user prompt.'
        },
        targetUser: {
          value: idea.audience,
          source: 'user_provided',
          confidence: 'high',
          rationale: 'Primary target customer segment.'
        }
      },
      stage2Position: {
        ...PRESET_BRANDS[0].stage2Position,
        problem: {
          value: idea.problem,
          source: 'user_provided',
          confidence: 'high',
          rationale: 'Core pain point.'
        },
        targetAudience: {
          value: idea.audience,
          source: 'user_provided',
          confidence: 'high',
          rationale: 'Target buyer.'
        },
        valueProposition: {
          value: `The dedicated platform built to eliminate ${idea.problem.slice(0, 45)}... with zero unnecessary overhead.`,
          source: 'ai_recommendation',
          confidence: 'high',
          rationale: 'Direct outcome statement.'
        },
        positioningStatement: {
          value: `For ${idea.audience}, ${idea.title} is the dedicated solution that solves ${idea.problem.slice(0, 45)}... unlike legacy alternatives that add more friction than they solve.`,
          source: 'ai_recommendation',
          confidence: 'high',
          rationale: 'Structured positioning blueprint.'
        }
      },
      stage3Shape: {
        ...PRESET_BRANDS[0].stage3Shape,
        selectedName: {
          value: idea.title,
          source: 'user_provided',
          confidence: 'high',
          rationale: 'Proposed brand name.'
        },
        messaging: {
          ...PRESET_BRANDS[0].stage3Shape.messaging,
          selectedTagline: {
            value: `Engineered for ${idea.audience.slice(0, 30)}. Ready for scale.`,
            source: 'ai_recommendation',
            confidence: 'high',
            rationale: 'Audience-grounded tagline.'
          },
          oneLinePitch: {
            value: `${idea.title} solves ${idea.problem.slice(0, 50)} for ${idea.audience}.`,
            source: 'ai_recommendation',
            confidence: 'high',
            rationale: 'Crisp elevator pitch.'
          }
        }
      },
      stage6Launch: {
        ...PRESET_BRANDS[0].stage6Launch,
        landingPageHeadline: {
          value: `The end of ${idea.problem.slice(0, 35)}.`,
          source: 'ai_recommendation',
          confidence: 'high',
          rationale: 'High-contrast benefit headline.'
        },
        landingPageSubhead: {
          value: `${idea.title} gives ${idea.audience} the dedicated platform to eliminate friction and scale results.`,
          source: 'ai_recommendation',
          confidence: 'high',
          rationale: 'Clear customer-facing subhead.'
        },
        socialLaunchPost: {
          value: `Most tools in ${idea.category} are bloated, slow, and full of friction.\n\nToday we are announcing ${idea.title}.\n\nBuilt specifically for ${idea.audience} to eliminate ${idea.problem.slice(0, 35)}.\n\nExplore the system: ${brandId}.io`,
          source: 'ai_recommendation',
          confidence: 'high',
          rationale: 'Launch announcement copy.'
        }
      },
      stage65LockedDNA: {
        ...PRESET_BRANDS[0].stage65LockedDNA,
        brandName: idea.title,
        confirmedAudience: idea.audience,
        problem: idea.problem,
        tagline: `Engineered for ${idea.audience.slice(0, 30)}. Ready for scale.`
      }
    };

    setCurrentBrand(customBrand);
    // Smooth scroll down to the neat dashboard
    window.scrollTo({ top: 380, behavior: 'smooth' });
  };

  const handleSelectPreset = (brandId: string) => {
    const found = PRESET_BRANDS.find(b => b.id === brandId);
    if (found) {
      setCurrentBrand(found);
      window.scrollTo({ top: 380, behavior: 'smooth' });
    }
  };

  const handleToggleLock = () => {
    const updatedLockedDna = {
      ...currentBrand.stage65LockedDNA,
      isLocked: !currentBrand.stage65LockedDNA.isLocked,
      lockedAt: !currentBrand.stage65LockedDNA.isLocked ? new Date().toISOString() : undefined
    };
    setCurrentBrand({
      ...currentBrand,
      stage65LockedDNA: updatedLockedDna
    });
  };

  return (
    <div className="min-h-screen bg-ivory text-ink flex flex-col font-sans">
      {/* Minimal premium navigation */}
      <header className="sticky top-0 z-40 w-full border-b border-hairline-dark bg-charcoal/95 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Wordmark */}
          <div className="flex items-center gap-2.5">
            <span className="text-[15px] sm:text-base font-semibold tracking-tight text-ivory font-display italic">
              BrandEngine
            </span>
            <span className="hidden sm:inline-block eyebrow text-accent-light/90 border border-hairline-dark rounded-full px-2 py-0.5">
              AI Brand System
            </span>
          </div>

          {/* Right controls */}
          <div className="flex items-center gap-2.5">
            {/* Preset showcase dropdown */}
            <div className="relative group">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-hairline-dark text-xs text-ivory/80 hover:border-ivory/30 transition cursor-pointer">
                <span className="text-ivory/40 hidden md:inline">Example</span>
                <span className="font-semibold text-ivory">{currentBrand.name}</span>
                <ChevronDown className="w-3.5 h-3.5 text-ivory/40" />
              </div>

              <div className="absolute right-0 mt-2 w-64 rounded-xl panel-dark shadow-2xl p-1.5 hidden group-hover:block transition-all z-50">
                <div className="px-3 py-1.5 eyebrow text-ivory/40 border-b border-hairline-dark mb-1">
                  Ready-Made Examples
                </div>
                {PRESET_BRANDS.map(b => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => handleSelectPreset(b.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition cursor-pointer ${
                      b.id === currentBrand.id
                        ? 'bg-accent/15 text-accent-light font-semibold'
                        : 'text-ivory/70 hover:bg-white/5'
                    }`}
                  >
                    <div>
                      <div>{b.name}</div>
                      <div className="text-[10px] text-ivory/35">{b.industry}</div>
                    </div>
                    {b.id === currentBrand.id && (
                      <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Lock DNA toggle */}
            <button
              type="button"
              onClick={handleToggleLock}
              className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition cursor-pointer ${
                currentBrand.stage65LockedDNA.isLocked
                  ? 'border-emerald-500/30 text-emerald-300'
                  : 'border-amber-500/30 text-amber-300'
              }`}
              title="Lock Brand DNA as fixed reference"
            >
              {currentBrand.stage65LockedDNA.isLocked ? (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>Locked</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Draft</span>
                </>
              )}
            </button>

            {/* Primary CTA */}
            <button
              type="button"
              onClick={() => setIsExportOpen(true)}
              className="btn-accent px-4 py-1.5 rounded-full text-xs font-semibold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Kit</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero + idea input */}
      <HeroIdeaInput
        onProposeIdea={handleProposeIdea}
        onSelectPreset={handleSelectPreset}
        currentBrandName={currentBrand.name}
      />

      {/* Brand workspace */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <NeatBrandDashboard
          brand={currentBrand}
          onUpdateBrand={setCurrentBrand}
          onOpenExportModal={() => setIsExportOpen(true)}
        />
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-hairline-dark bg-charcoal py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 eyebrow text-ivory/40">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>AI Brand Intelligence Engine — Strategist + Skeptic Workflow</span>
          </div>
          <div className="eyebrow text-ivory/40">
            Active — <b className="text-ivory/80 font-mono">{currentBrand.name}</b> · {currentBrand.industry}
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        brand={currentBrand}
      />

      <NewBrandModal
        isOpen={isNewBrandOpen}
        onClose={() => setIsNewBrandOpen(false)}
        onCreateBrand={(newBrand) => {
          setCurrentBrand(newBrand);
          window.scrollTo({ top: 380, behavior: 'smooth' });
        }}
      />
    </div>
  );
};

export default App;
