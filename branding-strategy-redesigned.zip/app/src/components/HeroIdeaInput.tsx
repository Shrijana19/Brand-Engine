import React, { useState } from 'react';
import { Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';

interface Props {
  onProposeIdea: (idea: { title: string; problem: string; audience: string; category: string }) => void;
  onSelectPreset: (brandId: string) => void;
  currentBrandName: string;
}

export const HeroIdeaInput: React.FC<Props> = ({
  onProposeIdea,
  onSelectPreset,
  currentBrandName
}) => {
  const [ideaText, setIdeaText] = useState('');
  const [category, setCategory] = useState('SaaS');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const sampleIdeas = [
    {
      label: 'ICU Nurse Workload Telemetry',
      id: 'kora-health',
      title: 'Kora Health',
      prompt: 'A zero-tap telemetry badge that catches ICU nurse fatigue before acute burnout occurs.',
      category: 'HealthTech'
    },
    {
      label: 'Medical Cold-Chain Drone Transit',
      id: 'aetheria-logistics',
      title: 'Aetheria',
      prompt: 'Sub-10 minute rooftop drone courier for urgent hospital biopsy specimens and radiopharma.',
      category: 'CleanTech'
    },
    {
      label: 'Spatial Audio Game Engine',
      id: 'custom-vektor',
      title: 'Vektor Audio',
      prompt: 'An open-source real-time spatial acoustics engine for indie Unity and Unreal developers.',
      category: 'DevTools'
    },
    {
      label: 'Fermented Micro-Lot Coffee',
      id: 'custom-soma',
      title: 'Soma Roast',
      prompt: 'Fermentation-forward micro-lot coffee club connecting Colombian farms directly to roasters.',
      category: 'Consumer'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ideaText.trim()) return;

    setIsAnalyzing(true);
    setTimeout(() => {
      const words = ideaText.trim().split(' ');
      const candidateTitle = words.slice(0, 2).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

      onProposeIdea({
        title: candidateTitle || 'Nova Brand',
        problem: ideaText.trim(),
        audience: 'Modern teams looking for high reliability, fast deployment, and clear results',
        category
      });
      setIsAnalyzing(false);
      setIdeaText('');
    }, 450);
  };

  const handleSelectSample = (sample: typeof sampleIdeas[0]) => {
    if (sample.id === 'kora-health' || sample.id === 'aetheria-logistics') {
      onSelectPreset(sample.id);
    } else {
      setIdeaText(sample.prompt);
      setCategory(sample.category);
    }
  };

  return (
    <section className="relative overflow-hidden border-b border-hairline bg-ivory">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-14 sm:pt-24 sm:pb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-end">
          {/* Left: eyebrow + oversized headline + copy */}
          <div className="lg:col-span-8 space-y-6">
            <div className="flex items-center gap-2 eyebrow text-muted">
              <span className="text-ink">Brand Strategy</span>
              <span className="text-hairline">/</span>
              <span>01</span>
            </div>

            <h1 className="font-display italic text-[2.6rem] leading-[1.04] sm:text-6xl sm:leading-[0.98] lg:text-7xl lg:leading-[0.95] text-ink tracking-tight text-balance">
              Turn any idea into
              <br />
              a brand people
              <br />
              <span className="text-accent">remember.</span>
            </h1>

            <p className="text-sm sm:text-base text-muted max-w-md leading-relaxed">
              Describe your idea below. The Strategist develops positioning, naming, and messaging — the Skeptic
              strips out clichés and weak differentiation — and hands back a launch-ready brand system.
            </p>
          </div>

          {/* Right: status readout, standing in for the 3D signature element */}
          <div className="lg:col-span-4 flex lg:justify-end">
            <div className="w-full max-w-xs panel rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-muted">Active Brand</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              </div>
              <div>
                <div className="text-xl font-display italic text-ink">{currentBrandName}</div>
                <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium mt-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Launch Ready
                </div>
              </div>
              <div className="pt-3 border-t border-hairline text-[11px] text-muted leading-relaxed">
                Discover → Position → Shape → Visualize → Challenge → Launch → Monitor
              </div>
            </div>
          </div>
        </div>

        {/* Immersive idea input */}
        <div className="pt-12 sm:pt-16 max-w-3xl">
          <span className="eyebrow text-muted block mb-3">What does your idea solve?</span>

          <form onSubmit={handleSubmit} className="border-b-2 border-ink focus-within:border-accent transition-colors pb-3">
            <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
              <input
                type="text"
                value={ideaText}
                onChange={(e) => setIdeaText(e.target.value)}
                placeholder="An AI tool that alerts ICU nurses before burnout…"
                className="flex-1 bg-transparent text-lg sm:text-2xl font-display italic text-ink placeholder-muted/50 focus:outline-none"
              />

              <div className="flex items-center gap-2 shrink-0">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="px-2.5 py-1.5 rounded-full bg-transparent border border-hairline text-[11px] font-medium text-muted focus:outline-none"
                >
                  <option value="SaaS">SaaS</option>
                  <option value="HealthTech">HealthTech</option>
                  <option value="CleanTech">CleanTech</option>
                  <option value="Consumer">Consumer</option>
                  <option value="DevTools">DevTools</option>
                </select>

                <button
                  type="submit"
                  disabled={isAnalyzing || !ideaText.trim()}
                  className="btn-primary px-5 py-2 rounded-full text-xs font-semibold cursor-pointer"
                >
                  {isAnalyzing ? (
                    <>
                      <Sparkles className="w-3.5 h-3.5 animate-spin" />
                      <span>Generating</span>
                    </>
                  ) : (
                    <>
                      <span>Start Your Strategy</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>

          {/* Quick idea samples */}
          <div className="flex flex-wrap items-center gap-2 pt-4">
            <span className="eyebrow text-muted mr-1">Explore the Process</span>
            {sampleIdeas.map((s, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelectSample(s)}
                className={`link-underline px-0.5 py-1 text-[11px] font-medium transition cursor-pointer ${
                  currentBrandName === s.title ? 'text-accent' : 'text-muted hover:text-ink'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
