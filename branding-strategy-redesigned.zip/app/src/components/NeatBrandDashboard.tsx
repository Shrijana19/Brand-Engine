import React, { useState } from 'react';
import { BrandSystem } from '../types/brand';
import {
  Sparkles,
  Target,
  Palette,
  Rocket,
  ShieldCheck,
  Copy,
  Check,
  Download,
  Compass,
  AlertTriangle,
  Lightbulb,
  CheckCircle2,
  Share2,
  Mail,
  Eye,
  GitFork
} from 'lucide-react';
import { Stage35GraphView } from './stages/Stage35GraphView';
import { Stage7GuardianView } from './stages/Stage7GuardianView';
import { Stage75DriftView } from './stages/Stage75DriftView';

interface Props {
  brand: BrandSystem;
  onUpdateBrand: (updated: BrandSystem) => void;
  onOpenExportModal: () => void;
}

export type NeatTab = 'overview' | 'stress_test' | 'visuals' | 'launch_kit' | 'guardian' | 'dna_map';

export const NeatBrandDashboard: React.FC<Props> = ({
  brand,
  onUpdateBrand,
  onOpenExportModal
}) => {
  const [activeTab, setActiveTab] = useState<NeatTab>('overview');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const tabs = [
    { id: 'overview' as NeatTab, number: '01', label: 'Brand Overview', icon: Target, desc: 'Positioning & Audience' },
    { id: 'stress_test' as NeatTab, number: '02', label: 'What the AI Fixed', icon: Compass, desc: 'Clichés Removed' },
    { id: 'visuals' as NeatTab, number: '03', label: 'Visual Identity', icon: Palette, desc: 'Logo & Colors' },
    { id: 'launch_kit' as NeatTab, number: '04', label: 'Ready-to-Post Copy', icon: Rocket, desc: 'Website, Posts & Email' },
    { id: 'guardian' as NeatTab, number: '05', label: 'Brand Guardian', icon: ShieldCheck, desc: 'Live Post Auditor' },
    { id: 'dna_map' as NeatTab, number: '06', label: 'System DNA Graph', icon: GitFork, desc: 'Node Dependencies' }
  ];

  return (
    <div className="space-y-10 max-w-5xl mx-auto">
      {/* 1. TOP BRAND HERO CARD */}
      <div className="p-7 sm:p-10 rounded-2xl panel relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div className="space-y-4 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="eyebrow text-muted">{brand.industry}</span>
              <span className="text-hairline">·</span>
              <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Launch Ready
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-display italic text-ink tracking-tight">
              {brand.name}
            </h1>

            <p className="text-lg sm:text-xl text-accent font-display italic">
              "{brand.stage3Shape.messaging.selectedTagline.value}"
            </p>

            <p className="text-sm text-muted leading-relaxed max-w-xl">
              {brand.stage2Position.valueProposition.value}
            </p>
          </div>

          {/* Quick actions */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onOpenExportModal}
              className="btn-primary px-5 py-2.5 rounded-full font-semibold text-xs cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Brand Kit</span>
            </button>

            <button
              type="button"
              onClick={() => copyText(brand.stage3Shape.messaging.selectedTagline.value, 'hero-tagline')}
              className="btn-ghost px-4 py-2.5 rounded-full text-xs font-medium cursor-pointer"
            >
              {copiedKey === 'hero-tagline' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Tagline Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-muted" />
                  <span>Copy Tagline</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 2. NUMBERED SECTION NAVIGATION */}
      <div className="space-y-3">
        <div className="flex items-center justify-between eyebrow text-muted px-1">
          <span>Brand Sections</span>
          <span className="hidden sm:inline">Select to view details</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  isActive
                    ? 'bg-ink border-ink text-ivory shadow-sm'
                    : 'bg-paper border-hairline text-muted hover:border-ink/30 hover:text-ink'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`index-number text-[10px] ${isActive ? 'text-accent-light' : 'text-muted/70'}`}>
                    {tab.number}
                  </span>
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-accent-light' : 'text-muted/60'}`} />
                </div>
                <span className={`font-semibold text-xs line-clamp-1 ${isActive ? 'text-ivory' : 'text-ink'}`}>{tab.label}</span>
                <span className={`text-[11px] line-clamp-1 mt-0.5 ${isActive ? 'text-ivory/50' : 'text-muted'}`}>{tab.desc}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. TAB 1: BRAND OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="p-3.5 rounded-xl bg-accent-soft/60 border border-accent/20 text-xs text-ink/80 flex items-center gap-2.5">
            <Lightbulb className="w-4 h-4 text-accent shrink-0" />
            <span>
              <b className="text-ink">Quick Summary:</b> Your brand foundation. Clear positioning, target customer, and what sets you apart from competitors.
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* The One-Line Pitch */}
            <div className="p-5 rounded-2xl panel space-y-2">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-accent">Elevator Pitch</span>
                <button
                  type="button"
                  onClick={() => copyText(brand.stage3Shape.messaging.oneLinePitch.value, 'one-line')}
                  className="p-1 rounded text-muted hover:text-ink"
                  title="Copy pitch"
                >
                  {copiedKey === 'one-line' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
              <p className="text-sm text-ink font-medium leading-relaxed font-serif">
                "{brand.stage3Shape.messaging.oneLinePitch.value}"
              </p>
            </div>

            {/* Core Differentiator */}
            <div className="p-5 rounded-2xl bg-ink text-ivory space-y-2">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-accent-light flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  What Makes You Unique
                </span>
              </div>
              <p className="text-sm text-ivory/90 font-medium leading-relaxed">
                {brand.stage2Position.differentiator.value}
              </p>
            </div>
          </div>

          {/* Problem & Audience */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl panel space-y-3">
              <div>
                <span className="eyebrow text-muted block mb-1">Who Buys This</span>
                <p className="text-sm text-ink font-medium">
                  {brand.stage1Discover.targetUser.value}
                </p>
              </div>

              <div className="pt-3 border-t border-hairline">
                <span className="eyebrow text-muted block mb-1">Problem Solved</span>
                <p className="text-sm text-muted leading-relaxed">
                  {brand.stage1Discover.problem.value}
                </p>
              </div>
            </div>

            {/* Personality / Tone */}
            <div className="p-5 rounded-2xl panel space-y-2">
              <span className="eyebrow text-muted block mb-1">Tone of Voice</span>
              <div className="space-y-2">
                {brand.stage3Shape.personality.value.map((trait, idx) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-ivory border border-hairline text-xs">
                    <div className="font-bold text-accent">{trait.trait}</div>
                    <div className="text-muted mt-0.5">{trait.howItShowsUp}</div>
                    <div className="text-[11px] text-rose-700/80 mt-0.5 italic">
                      Avoid: {trait.adjacentTraitToAvoid}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Rules: What NOT to Sound Like */}
          <div className="p-4 rounded-xl panel space-y-2 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-ink">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Boundary Rules: What This Brand Must Never Sound Like</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-ink/80">
              {brand.stage2Position.whatThisShouldNotTryToBe.value.map((rule, idx) => (
                <div key={idx} className="p-2 rounded-lg bg-ivory border border-hairline text-xs flex items-start gap-1.5">
                  <span className="text-rose-600 font-bold">✕</span>
                  <span>{rule}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. TAB 2: WHAT THE AI FIXED */}
      {activeTab === 'stress_test' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="p-3.5 rounded-xl bg-accent-soft/60 border border-accent/20 text-xs text-ink/80 flex items-center gap-2.5">
            <Lightbulb className="w-4 h-4 text-accent shrink-0" />
            <span>
              <b className="text-ink">Before &amp; After:</b> How the Skeptic AI attacked generic startup clichés to sharpen your message.
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Initial Proposal */}
            <div className="p-5 rounded-2xl panel space-y-2">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-muted flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-muted" /> 01 — Initial Draft
                </span>
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-ivory border border-hairline text-muted">
                  Too Vague
                </span>
              </div>
              <p className="text-xs text-muted leading-relaxed pt-1">
                {brand.stage2Position.exchange.strategistProposal}
              </p>
            </div>

            {/* Skeptic Attack */}
            <div className="p-5 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-rose-800 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600" /> 02 — Fluff Attacked
                </span>
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-rose-100 text-rose-700">
                  Clichés Flagged
                </span>
              </div>
              <p className="text-xs text-rose-900 leading-relaxed pt-1">
                "{brand.stage2Position.exchange.skepticCritique}"
              </p>
            </div>

            {/* Refined Final Version */}
            <div className="p-5 rounded-2xl bg-ink text-ivory space-y-2">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-accent-light flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-accent-light" /> 03 — Refined Version
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/10 text-ivory">
                  Score: 9.3/10
                </span>
              </div>
              <p className="text-xs text-ivory/90 font-medium leading-relaxed pt-1">
                {brand.stage2Position.exchange.strategistRevision}
              </p>
            </div>
          </div>

          {/* Prohibited Clichés List */}
          <div className="p-5 rounded-2xl panel space-y-2">
            <h4 className="eyebrow text-muted">
              Words Banned From Your Marketing Copy
            </h4>
            <div className="flex flex-wrap gap-2 pt-1">
              {brand.stage65LockedDNA.prohibitedCliches.map((cliche, idx) => (
                <span key={idx} className="px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium">
                  {cliche}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 5. TAB 3: VISUAL IDENTITY */}
      {activeTab === 'visuals' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="p-3.5 rounded-xl bg-accent-soft/60 border border-accent/20 text-xs text-ink/80 flex items-center gap-2.5">
            <Lightbulb className="w-4 h-4 text-accent shrink-0" />
            <span>
              <b className="text-ink">Visual Identity:</b> Download your brand logo in SVG format and copy your hex codes directly.
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            {/* Logo Viewer */}
            <div className="md:col-span-5 p-6 rounded-2xl panel flex flex-col items-center justify-between text-center space-y-4">
              <span className="eyebrow text-muted">SVG Logo Mark</span>

              <div className="w-44 h-44 rounded-2xl flex items-center justify-center p-6 border border-hairline bg-ivory">
                <div
                  className="w-full h-full flex items-center justify-center"
                  dangerouslySetInnerHTML={{ __html: brand.stage4Visualize.svgLogoCode }}
                />
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-display italic text-ink">{brand.name} Icon</h4>
                <p className="text-xs text-muted max-w-xs">{brand.stage4Visualize.logoDirection.value}</p>
              </div>
            </div>

            {/* Colors & Typography */}
            <div className="md:col-span-7 space-y-4">
              {/* Color Swatches */}
              <div className="p-5 rounded-2xl panel space-y-3">
                <span className="eyebrow text-muted block">
                  Color Palette — Click to Copy Hex
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {brand.stage4Visualize.colorPalette.map((color, idx) => (
                    <div
                      key={idx}
                      onClick={() => copyText(color.hex, `color-${idx}`)}
                      className="p-2 rounded-xl bg-ivory border border-hairline hover:border-accent cursor-pointer transition space-y-1.5"
                    >
                      <div className="w-full h-8 rounded-lg border border-black/5" style={{ backgroundColor: color.hex }} />
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-ink font-medium truncate">{color.name}</span>
                        <span className="font-mono text-[11px] text-muted">
                          {copiedKey === `color-${idx}` ? 'Copied' : color.hex}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Typography */}
              <div className="p-5 rounded-2xl panel space-y-2">
                <span className="eyebrow text-muted block mb-1">
                  Google Fonts Pairing
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {brand.stage4Visualize.typography.map((font, idx) => (
                    <div key={idx} className="p-2.5 rounded-lg bg-ivory border border-hairline">
                      <div className="text-accent font-semibold text-[11px] uppercase tracking-wide">{font.role}</div>
                      <div className="text-ink font-bold text-sm my-0.5">{font.fontFamily}</div>
                      <div className="text-muted text-[11px]">{font.usageNotes}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. TAB 4: READY-TO-POST LAUNCH COPY */}
      {activeTab === 'launch_kit' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="p-3.5 rounded-xl bg-accent-soft/60 border border-accent/20 text-xs text-ink/80 flex items-center gap-2.5">
            <Lightbulb className="w-4 h-4 text-accent shrink-0" />
            <span>
              <b className="text-ink">Launch Collateral:</b> Ready-to-use headlines, social announcement posts, and outreach emails.
            </span>
          </div>

          {/* Website Hero Card Mockup */}
          <div className="p-6 rounded-2xl panel space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-hairline text-xs">
              <span className="eyebrow text-accent flex items-center gap-1.5">
                <Eye className="w-4 h-4" /> Website Landing Page Hero
              </span>
              <button
                type="button"
                onClick={() => copyText(`${brand.stage6Launch.landingPageHeadline.value}\n\n${brand.stage6Launch.landingPageSubhead.value}`, 'web-hero')}
                className="btn-ghost inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-medium cursor-pointer"
              >
                {copiedKey === 'web-hero' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'web-hero' ? 'Copied' : 'Copy Hero Copy'}</span>
              </button>
            </div>

            <div className="space-y-2 max-w-2xl py-1">
              <h2 className="text-2xl sm:text-3xl font-display italic text-ink tracking-tight leading-tight">
                {brand.stage6Launch.landingPageHeadline.value}
              </h2>
              <p className="text-sm sm:text-base text-muted leading-relaxed">
                {brand.stage6Launch.landingPageSubhead.value}
              </p>
              <div className="pt-2 flex items-center gap-2">
                <span className="px-4 py-2 rounded-full bg-ink text-ivory font-semibold text-xs">
                  Get Started Free
                </span>
                <span className="px-4 py-2 rounded-full border border-hairline text-ink font-medium text-xs">
                  Book Demo
                </span>
              </div>
            </div>
          </div>

          {/* Social Post & Email Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Social Announcement */}
            <div className="p-5 rounded-2xl panel space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="eyebrow text-accent flex items-center gap-1.5">
                    <Share2 className="w-3.5 h-3.5" /> Social Announcement
                  </span>
                  <button
                    type="button"
                    onClick={() => copyText(brand.stage6Launch.socialLaunchPost.value, 'social-post')}
                    className="p-1 rounded text-muted hover:text-ink"
                  >
                    {copiedKey === 'social-post' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="p-3.5 rounded-xl bg-ivory border border-hairline text-xs text-ink/90 whitespace-pre-line leading-relaxed">
                  {brand.stage6Launch.socialLaunchPost.value}
                </div>
              </div>
            </div>

            {/* Direct Outreach Email */}
            <div className="p-5 rounded-2xl panel space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="eyebrow text-accent flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5" /> Buyer Outreach Email
                  </span>
                  <button
                    type="button"
                    onClick={() => copyText(`Subject: ${brand.stage6Launch.launchEmailSubject.value}\n\n${brand.stage6Launch.launchEmailBody.value}`, 'email-post')}
                    className="p-1 rounded text-muted hover:text-ink"
                  >
                    {copiedKey === 'email-post' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="p-3.5 rounded-xl bg-ivory border border-hairline space-y-1.5 text-xs text-ink/90">
                  <div className="text-muted pb-1 border-b border-hairline font-medium">
                    <b>Subject:</b> {brand.stage6Launch.launchEmailSubject.value}
                  </div>
                  <div className="whitespace-pre-line leading-relaxed pt-1">
                    {brand.stage6Launch.launchEmailBody.value}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. TAB 5: BRAND GUARDIAN */}
      {activeTab === 'guardian' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="p-3.5 rounded-xl bg-accent-soft/60 border border-accent/20 text-xs text-ink/80 flex items-center gap-2.5">
            <Lightbulb className="w-4 h-4 text-accent shrink-0" />
            <span>
              <b className="text-ink">Live Brand Checker:</b> Paste any future ad, tweet, or email below to check if it matches your brand rules and get automatic rewrites.
            </span>
          </div>

          <Stage7GuardianView brand={brand} onUpdateBrand={onUpdateBrand} />
          <Stage75DriftView brand={brand} onUpdateBrand={onUpdateBrand} onNavigateToGuardian={() => {}} />
        </div>
      )}

      {/* 8. TAB 6: ADVANCED DNA GRAPH */}
      {activeTab === 'dna_map' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          <div className="p-3.5 rounded-xl bg-accent-soft/60 border border-accent/20 text-xs text-ink/80 flex items-center gap-2.5">
            <Lightbulb className="w-4 h-4 text-accent shrink-0" />
            <span>
              <b className="text-ink">System DNA:</b> View how decisions connect. If you edit any node, affected downstream marketing copy updates automatically.
            </span>
          </div>

          <Stage35GraphView brand={brand} onUpdateBrand={onUpdateBrand} />
        </div>
      )}
    </div>
  );
};
