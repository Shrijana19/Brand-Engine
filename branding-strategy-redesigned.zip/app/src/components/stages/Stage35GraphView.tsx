import React, { useState } from 'react';
import { BrandSystem, DnaNode, DnaNodeType } from '../../types/brand';
import { propagateDnaChange, getDownstreamNodes } from '../../services/brandEngine';
import {
  GitFork,
  ArrowRight,
  AlertCircle,
  RefreshCw,
  Edit3,
  History,
  Sparkles
} from 'lucide-react';

interface Props {
  brand: BrandSystem;
  onUpdateBrand: (updated: BrandSystem) => void;
}

export const Stage35GraphView: React.FC<Props> = ({ brand, onUpdateBrand }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<DnaNodeType>('positioning');
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState('');
  const [editReason, setEditReason] = useState('');

  const selectedNode = brand.stage35Graph.find(n => n.id === selectedNodeId) || brand.stage35Graph[0];
  const downstreamAffected = getDownstreamNodes(selectedNodeId, brand.stage35Graph);

  const startEdit = () => {
    setEditValue(selectedNode.summary);
    setEditReason(`User requested adjustment to ${selectedNode.label} based on updated requirements.`);
    setIsEditing(true);
  };

  const handleApplyChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editValue.trim()) return;

    const { updatedBrand } = propagateDnaChange(
      brand,
      selectedNodeId,
      editValue.trim(),
      editReason.trim() || 'Direct manual strategic adjustment.'
    );

    onUpdateBrand(updatedBrand);
    setIsEditing(false);
  };

  const getStatusBadge = (status: DnaNode['status']) => {
    switch (status) {
      case 'CONFIRMED':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'RECOMMENDED':
        return 'bg-accent-soft text-accent-deep border-accent/30';
      case 'UNVERIFIED':
        return 'bg-amber-50 text-amber-700 border-amber-200';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-hairline">
        <div>
          <div className="eyebrow text-accent mb-1">
            Stage 3.5 — Brand DNA Graph
          </div>
          <h2 className="text-2xl font-display italic text-ink tracking-tight">
            Connected System &amp; Change Propagation
          </h2>
          <p className="text-sm text-muted mt-1 max-w-xl">
            Brands are connected systems, not isolated decisions. Changing any node recalculates its downstream dependencies with a full causal diff.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-hairline text-xs font-mono shrink-0">
          <span className="text-muted">Nodes</span>
          <span className="text-ink font-bold">{brand.stage35Graph.length}</span>
          <span className="text-hairline">|</span>
          <span className="text-muted">History</span>
          <span className="text-emerald-700 font-bold">{brand.causalDiffHistory.length}</span>
        </div>
      </div>

      {/* Interactive DAG Topological Flow Grid */}
      <div className="p-6 rounded-2xl panel space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="eyebrow text-muted flex items-center gap-2">
            <GitFork className="w-4 h-4 text-accent" />
            Dependency Chain — Click a Node to Inspect &amp; Propagate
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 pt-2">
          {brand.stage35Graph.map((node, index) => {
            const isSelected = selectedNodeId === node.id;
            const isDownstream = downstreamAffected.includes(node.id);

            return (
              <button
                key={node.id}
                type="button"
                onClick={() => {
                  setSelectedNodeId(node.id);
                  setIsEditing(false);
                }}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-ink border-ink text-ivory shadow-sm'
                    : isDownstream
                    ? 'bg-amber-50 border-amber-300 hover:border-amber-400'
                    : 'bg-ivory border-hairline hover:border-ink/30'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`index-number text-[10px] font-semibold ${isSelected ? 'text-accent-light' : 'text-muted'}`}>
                      0{index + 1}
                    </span>
                    <span className={`text-[9px] font-mono px-1 rounded border ${isSelected ? 'bg-white/10 border-white/20 text-ivory/80' : getStatusBadge(node.status)}`}>
                      {node.status}
                    </span>
                  </div>
                  <h4 className={`text-xs font-bold line-clamp-1 ${isSelected ? 'text-ivory' : 'text-ink'}`}>
                    {node.label}
                  </h4>
                  <p className={`text-[11px] line-clamp-2 mt-1 leading-snug ${isSelected ? 'text-ivory/60' : 'text-muted'}`}>
                    {node.summary}
                  </p>
                </div>

                {isDownstream && !isSelected && (
                  <div className="mt-2 pt-1 border-t border-amber-200 text-[9px] font-mono text-amber-700 flex items-center gap-1">
                    <RefreshCw className="w-2.5 h-2.5" />
                    <span>Downstream</span>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Node Inspector & Change Propagation Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Node Inspector Detail */}
        <div className="lg:col-span-2 p-6 rounded-2xl panel space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-hairline gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono uppercase font-bold border ${getStatusBadge(selectedNode.status)}`}>
                  {selectedNode.status}
                </span>
                <span className="text-xs font-mono text-muted">Node ID: {selectedNode.id}</span>
              </div>
              <h3 className="text-xl font-display italic text-ink mt-1">
                {selectedNode.label}
              </h3>
            </div>

            {!isEditing && (
              <button
                type="button"
                onClick={startEdit}
                className="btn-primary inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Simulate Node Change</span>
              </button>
            )}
          </div>

          {isEditing ? (
            <form onSubmit={handleApplyChange} className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="eyebrow text-accent flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Live Change Propagation Tool
                </span>
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="text-xs text-muted hover:text-ink"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-ink mb-1">
                  New Value for {selectedNode.label}:
                </label>
                <textarea
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 rounded-lg bg-ivory border border-hairline text-sm text-ink focus:outline-none focus:border-accent"
                  placeholder="Enter adjusted node definition..."
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-ink mb-1">
                  Change Rationale / Explanation:
                </label>
                <input
                  type="text"
                  value={editReason}
                  onChange={(e) => setEditReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-ivory border border-hairline text-xs text-ink focus:outline-none focus:border-accent"
                  placeholder="Reason for change..."
                />
              </div>

              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900">
                <span className="font-semibold text-amber-800">Downstream Impact Notice:</span>
                <p className="mt-1 text-[11px] leading-relaxed">
                  Saving this change will automatically flag {downstreamAffected.length} downstream nodes as requiring calibration and create a permanent Causal Diff entry.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 rounded-full text-xs text-muted hover:text-ink"
                >
                  Discard
                </button>
                <button
                  type="submit"
                  className="btn-accent px-4 py-1.5 rounded-full text-xs font-semibold"
                >
                  Propagate Change &amp; Recalculate
                </button>
              </div>
            </form>
          ) : (
            <div className="p-4 rounded-xl bg-ivory border border-hairline space-y-2">
              <span className="eyebrow text-muted">Current Node Content:</span>
              <p className="text-sm text-ink leading-relaxed font-medium">
                {selectedNode.summary}
              </p>
            </div>
          )}

          {/* Dependencies Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-ivory border border-hairline space-y-2">
              <span className="font-mono text-muted font-semibold flex items-center gap-1.5">
                <ArrowRight className="w-3.5 h-3.5 text-ink rotate-180" />
                Upstream Dependencies ({selectedNode.upstreamDependencies.length}):
              </span>
              {selectedNode.upstreamDependencies.length === 0 ? (
                <p className="text-muted italic">None (Root source node)</p>
              ) : (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedNode.upstreamDependencies.map(dep => (
                    <span key={dep} className="px-2 py-0.5 rounded bg-white border border-hairline text-ink font-mono text-[11px]">
                      {dep}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 rounded-xl bg-ivory border border-hairline space-y-2">
              <span className="font-mono text-muted font-semibold flex items-center gap-1.5">
                <ArrowRight className="w-3.5 h-3.5 text-emerald-700" />
                Downstream Dependencies ({selectedNode.downstreamDependencies.length}):
              </span>
              {selectedNode.downstreamDependencies.length === 0 ? (
                <p className="text-muted italic">None (Terminal leaf node)</p>
              ) : (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {selectedNode.downstreamDependencies.map(dep => (
                    <span key={dep} className="px-2 py-0.5 rounded bg-white border border-hairline text-emerald-700 font-mono text-[11px]">
                      {dep}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Contradiction Risks */}
          <div className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600" />
              <h4 className="eyebrow text-rose-800">
                Contradiction Risks Guarded By This Node:
              </h4>
            </div>
            <ul className="space-y-1 text-xs text-rose-900/90 pl-6 list-disc">
              {selectedNode.contradictionRisks.map((risk, i) => (
                <li key={i}>{risk}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Causal Diff History Trail */}
        <div className="p-6 rounded-2xl panel flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center gap-2 pb-3 mb-3 border-b border-hairline">
              <History className="w-4 h-4 text-accent" />
              <h4 className="text-sm font-display italic text-ink">
                Causal Diff Trail ({brand.causalDiffHistory.length})
              </h4>
            </div>

            <p className="text-xs text-muted mb-3">
              Every meaningful change preserves an audit trail of downstream regenerations:
            </p>

            <div className="space-y-3 overflow-y-auto max-h-[380px] pr-1">
              {brand.causalDiffHistory.map((diff, index) => (
                <div key={index} className="p-3.5 rounded-xl bg-ivory border border-hairline space-y-2 text-xs">
                  <div className="flex items-center justify-between text-[10px] font-mono text-muted">
                    <span className="text-accent font-bold uppercase">CHANGE: {diff.changedNode}</span>
                    <span>{new Date(diff.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  <div className="text-ink/80">
                    <span className="text-muted line-through mr-1.5">{diff.previousValue}</span>
                    <span className="text-emerald-700 font-medium">→ {diff.newValue}</span>
                  </div>

                  <div className="pt-2 border-t border-hairline">
                    <span className="text-[10px] font-mono uppercase text-muted block mb-1">
                      Downstream Effects:
                    </span>
                    <ul className="space-y-1 text-[11px] text-muted list-disc pl-4">
                      {diff.downstreamEffects.map((effect, i) => (
                        <li key={i}>{effect}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-hairline eyebrow text-muted text-center">
            Rule 10 — Never silently regenerate anything.
          </div>
        </div>
      </div>
    </div>
  );
};
