import React from 'react';
import { BrandSystem, GuardianEvaluation } from '../../types/brand';
import { calculateBrandDrift } from '../../services/brandEngine';
import {
  Activity,
  AlertTriangle,
  ShieldCheck,
  Info,
  Database,
  ArrowRight
} from 'lucide-react';

interface Props {
  brand: BrandSystem;
  onUpdateBrand: (updated: BrandSystem) => void;
  onNavigateToGuardian: () => void;
}

export const Stage75DriftView: React.FC<Props> = ({
  brand,
  onUpdateBrand,
  onNavigateToGuardian
}) => {
  const evaluations = brand.evaluationsHistory;
  const driftReport = brand.driftReport;

  // Seeder for demoing with limited time (labeled explicitly per prompt rule)
  const handleSeedSampleData = () => {
    const seedEvaluations: GuardianEvaluation[] = [
      {
        id: 'seed-1',
        timestamp: '2026-09-24T10:00:00Z',
        submittedContent: 'In high-acuity ICUs, cognitive debt compounds with every emergency alarm. Kora gives charge nurses ambient telemetry to rebalance assignments before clinicians break.',
        contentType: 'ad_copy',
        overallAlignmentScore: 9.4,
        breakdown: {
          voiceAlignment: 9,
          positioningAdherence: 9,
          differentiatorPresence: 9,
          audienceSpecificity: 10,
          clicheAvoidance: 10
        },
        lineByLineFeedback: [
          {
            lineText: 'In high-acuity ICUs, cognitive debt compounds with every alarm...',
            status: 'pass',
            feedback: 'Clinically grounded, precise target audience.'
          }
        ],
        avoidRuleViolations: [],
        intentPreservingRewrites: []
      },
      {
        id: 'seed-2',
        timestamp: '2026-09-24T11:30:00Z',
        submittedContent: 'Our smart shift software optimizes clinical hospital workflows and manages nurse shifts.',
        contentType: 'social_post',
        overallAlignmentScore: 5.6,
        breakdown: {
          voiceAlignment: 5,
          positioningAdherence: 5,
          differentiatorPresence: 4,
          audienceSpecificity: 6,
          clicheAvoidance: 7
        },
        lineByLineFeedback: [
          {
            lineText: 'Our smart shift software optimizes clinical hospital workflows...',
            status: 'warning',
            feedback: 'Loss of passive telemetry differentiator. Generic software framing.'
          }
        ],
        avoidRuleViolations: ['Vague optimization buzzword without clinical telemetry proof'],
        intentPreservingRewrites: []
      },
      {
        id: 'seed-3',
        timestamp: '2026-09-24T13:45:00Z',
        submittedContent: 'Empower healthcare heroes with next-gen AI to slash nurse overhead costs and maximize hospital margins!',
        contentType: 'pitch_line',
        overallAlignmentScore: 2.4,
        breakdown: {
          voiceAlignment: 2,
          positioningAdherence: 2,
          differentiatorPresence: 1,
          audienceSpecificity: 3,
          clicheAvoidance: 2
        },
        lineByLineFeedback: [
          {
            lineText: 'Empower healthcare heroes with next-gen AI...',
            status: 'fail',
            feedback: 'Banned clichés: "healthcare heroes", "next-gen AI". Toxic labor cost-cutting framing.'
          }
        ],
        avoidRuleViolations: [
          'Used prohibited term: "healthcare heroes"',
          'Used prohibited term: "next-gen"',
          'Cost-cutting framing violating Communication Principle #2'
        ],
        intentPreservingRewrites: []
      }
    ];

    const updatedDrift = calculateBrandDrift(seedEvaluations);

    onUpdateBrand({
      ...brand,
      evaluationsHistory: seedEvaluations,
      driftReport: updatedDrift
    });
  };

  const handleResetData = () => {
    const updatedHistory: GuardianEvaluation[] = [];
    const updatedDrift = calculateBrandDrift(updatedHistory);

    onUpdateBrand({
      ...brand,
      evaluationsHistory: updatedHistory,
      driftReport: updatedDrift
    });
  };

  const hasSufficientData = evaluations.length >= 3;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Stage Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-hairline">
        <div>
          <div className="eyebrow text-accent mb-1">
            Stage 7.5 — Brand Drift Detector
          </div>
          <h2 className="text-2xl font-display italic text-ink tracking-tight">
            Multi-Submission Drift Telemetry
          </h2>
          <p className="text-sm text-muted mt-1 max-w-xl">
            Monitors systemic brand degradation across time: rising corporate language, cliché creep, and differentiator dilution.
          </p>
        </div>

        {/* Data Honesty Seeder Controls */}
        <div className="flex items-center gap-2 border border-hairline p-1.5 rounded-full text-xs shrink-0">
          <span className="text-muted px-2 font-mono">Evaluations: {evaluations.length}</span>
          {!hasSufficientData ? (
            <button
              type="button"
              onClick={handleSeedSampleData}
              className="btn-primary px-3 py-1 rounded-full font-medium cursor-pointer flex items-center gap-1.5"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Load 3 Sample Posts</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleResetData}
              className="px-3 py-1 rounded-full bg-ivory border border-hairline hover:border-ink/30 text-muted hover:text-ink font-medium transition cursor-pointer"
            >
              Reset to 0 Submissions
            </button>
          )}
        </div>
      </div>

      {/* Strict Data Honesty Guardrail */}
      {!hasSufficientData ? (
        <div className="p-8 rounded-2xl panel space-y-6 text-center max-w-2xl mx-auto my-8">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto text-amber-600">
            <Activity className="w-7 h-7" />
          </div>

          <div className="space-y-3">
            <blockquote className="text-lg font-display italic text-ink bg-ivory p-4 rounded-xl border border-hairline">
              Insufficient historical data to establish a drift pattern.<br />
              <span className="text-sm font-sans not-italic text-muted">
                (Requires at least 3 prior evaluated submissions.)
              </span>
            </blockquote>
            <p className="text-xs text-muted leading-relaxed max-w-md mx-auto">
              The engine will never fabricate or hallucinate a trend from 1 or 2 data points. Submit content through the Consistency Guardian or load explicitly-labeled sample posts for demo testing.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleSeedSampleData}
              className="btn-primary w-full sm:w-auto px-5 py-2.5 rounded-full font-semibold text-xs"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Seed 3 Sample Posts (Clearly Labeled Demo)</span>
            </button>

            <button
              type="button"
              onClick={onNavigateToGuardian}
              className="btn-ghost w-full sm:w-auto px-5 py-2.5 rounded-full font-semibold text-xs"
            >
              <span>Go to Consistency Guardian</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        /* Multi-Submission Drift Report */
        <div className="space-y-6">
          {/* Diagnostic Notice */}
          <div className="p-4 rounded-xl panel flex items-center justify-between text-xs text-muted font-mono">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-accent" />
              <span>
                Diagnostic check against locked brand rules. Not a prediction of market or business performance.
              </span>
            </div>
            {driftReport.sampleDataNotice && (
              <span className="text-amber-700 hidden sm:inline">
                [{driftReport.sampleDataNotice}]
              </span>
            )}
          </div>

          {/* Drift Status Banner */}
          <div className={`p-6 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-6 ${
            driftReport.status === 'drift_detected'
              ? 'bg-rose-50/70 border-rose-200 text-rose-900'
              : 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
          }`}>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase font-bold border ${
                  driftReport.status === 'drift_detected'
                    ? 'bg-rose-100 text-rose-700 border-rose-200'
                    : 'bg-emerald-100 text-emerald-700 border-emerald-200'
                }`}>
                  {driftReport.direction?.replace('_', ' ').toUpperCase()} — SEVERITY: {driftReport.severity?.toUpperCase()}
                </span>
              </div>
              <h3 className="text-lg font-display italic">
                {driftReport.message}
              </h3>
            </div>

            <div className="shrink-0 flex items-center gap-3">
              <div className="p-3 rounded-xl bg-white/70 border border-black/5 text-center">
                <div className="text-[10px] font-mono opacity-70">Sample History</div>
                <div className="text-lg font-bold font-mono">{evaluations.length} Posts</div>
              </div>
            </div>
          </div>

          {/* Forensic Evidence & Recommended Correction */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl panel space-y-4">
              <h4 className="text-sm font-display italic text-ink flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>Forensic Drift Evidence Detected</span>
              </h4>
              <ul className="space-y-2 text-xs text-ink/80">
                {driftReport.evidence?.map((item, idx) => (
                  <li key={idx} className="p-3 rounded-xl bg-ivory border border-hairline flex items-start gap-2.5 leading-relaxed">
                    <span className="text-rose-600 font-bold">•</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-6 rounded-2xl bg-ink space-y-4">
              <h4 className="text-sm font-display italic text-ivory flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-accent-light" />
                <span>Recommended System Correction</span>
              </h4>
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs text-ivory/90 leading-relaxed">
                {driftReport.recommendedCorrection}
              </div>
              <div className="pt-2 text-[11px] font-mono text-ivory/50">
                Action: Update campaign briefing document to require validation prior to launch.
              </div>
            </div>
          </div>

          {/* Brand Health History Chart (Interactive Adherence Graph) */}
          {driftReport.trendScores && (
            <div className="p-6 rounded-2xl panel space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-hairline gap-2">
                <div>
                  <h4 className="text-sm font-display italic text-ink">
                    Brand Health History (Multi-Submission Adherence Trend)
                  </h4>
                  <p className="text-xs text-muted mt-0.5">
                    Measures adherence to defined brand system, not business success.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
                  <span className="flex items-center gap-1 text-ink">
                    <span className="w-2.5 h-2.5 rounded-full bg-ink" /> Alignment
                  </span>
                  <span className="flex items-center gap-1 text-accent">
                    <span className="w-2.5 h-2.5 rounded-full bg-accent" /> Voice
                  </span>
                  <span className="flex items-center gap-1 text-emerald-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" /> Differentiator
                  </span>
                </div>
              </div>

              {/* Visual Multi-Point Sparklines */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                {evaluations.map((evalItem, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-ivory border border-hairline space-y-3">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-muted">Submission 0{idx + 1}</span>
                      <span className={`px-2 py-0.5 rounded-full font-bold ${
                        evalItem.overallAlignmentScore >= 8
                          ? 'bg-emerald-100 text-emerald-700'
                          : evalItem.overallAlignmentScore >= 6
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}>
                        {evalItem.overallAlignmentScore}/10
                      </span>
                    </div>

                    <div className="space-y-1.5 text-[11px]">
                      <div className="flex justify-between text-muted">
                        <span>Voice:</span>
                        <span className="font-mono text-ink">{evalItem.breakdown.voiceAlignment}/10</span>
                      </div>
                      <div className="flex justify-between text-muted">
                        <span>Positioning:</span>
                        <span className="font-mono text-ink">{evalItem.breakdown.positioningAdherence}/10</span>
                      </div>
                      <div className="flex justify-between text-muted">
                        <span>Differentiator:</span>
                        <span className="font-mono text-ink">{evalItem.breakdown.differentiatorPresence}/10</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-hairline text-[10px] text-muted truncate">
                      "{evalItem.submittedContent}"
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
