# AI Brand Intelligence Engine

> **Battle-tested brand systems powered by a dual-persona Strategist vs. Skeptic protocol.**  
> Built with React 19, TypeScript, Vite, Tailwind CSS, and Lucide Icons.

---

## ⚡ Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build locally
npm run preview
```

---

## 🚀 Deployment & Publishing

This project is a 100% self-contained, static Single-Page Application (SPA) with zero external server dependencies. The production output in `dist/` can be deployed instantly to any host:

### Deploy to Vercel
```bash
npx vercel
```
Or connect your GitHub repository directly in the [Vercel Dashboard](https://vercel.com).
- **Framework Preset:** Vite
- **Build Command:** `npm run build`
- **Output Directory:** `dist`

### Deploy to Netlify
```bash
npx netlify deploy --prod --dir=dist
```
Or drag and drop the `dist/` folder into [Netlify Drop](https://app.netlify.com/drop).

### Deploy to GitHub Pages
Add a `base: './'` in `vite.config.ts` if deploying to a repository subpath, then run `npm run build` and push the `dist/` branch.

---

## 🧠 Architectural Overview

The **AI Brand Intelligence Engine** transforms incomplete ideas into distinctive, launch-ready brand systems, and keeps them honest after launch through continuous consistency monitoring.

### 1. Dual-Persona Architecture
Every creative stage executes a visible 3-step loop:
```
STRATEGIST (Proposes ideas, positioning, names, visuals)
   ↓
SKEPTIC (Attacks clichés, generic startup language, and audience mismatch)
   ↓
STRATEGIST REVISION (Refines output or certifies "No material weaknesses found")
```

### 2. Provenance Schema
Every substantive piece of brand data carries an explicit provenance tag:
- `user_provided` — Explicitly supplied by the user.
- `ai_assumption` — Inferred to bridge gaps; flagged for verification.
- `ai_recommendation` — Strategic recommendations subject to review.
- `unverified_external` — External market telemetry not independently validated.

### 3. Distinctiveness & Fit Score (with Escape Valve)
Scored 1–10 across:
1. **Cliché Density** (Lower generic/jargon language = Higher score)
2. **Audience Fit** (Specificity to target user)
3. **Differentiation** (Separation from category conventions)

*Hard Rule:* Maximum 2 revision cycles per stage. If still below 6, the engine displays an explicit escape-valve banner explaining why differentiation is constrained without infinite loops.

---

## 📋 Full 10-Stage Pipeline

| Stage | Name | Description |
|---|---|---|
| **1.0** | **Discover** | Identifies problem, target user, context, constraints, assumptions, and asks only 3–4 high-value questions. |
| **2.0** | **Position** | Defines category, value proposition, differentiator, and "What this brand must NEVER try to be". |
| **2.5** | **Market Scan** | Paraphrases competitor patterns and gaps. Degrades gracefully if research is unavailable. |
| **3.0** | **Shape the Brand** | 3–5 non-generic personality traits, naming territories (with trademark disclaimer), and messaging architecture. |
| **3.5** | **Brand DNA Graph** | Connected DAG representing 12 interdependent nodes with live change propagation & causal diffs. |
| **4.0** | **Visualize** | Generates SVG logo marks, typography scales, WCAG-compliant color tokens, and anti-cliché avoid rules. |
| **5.0** | **Challenge** | Cross-stage consolidated audit tracing findings through full causal chains (`BEFORE → PROBLEM → CHANGE → AFTER → DOWNSTREAM EFFECTS`). |
| **6.0** | **Launch Kit** | Consistency conflict detection, hero headlines, elevator pitches, social posts, and launch emails. |
| **6.5** | **Brand Lock** | Freezes approved decisions into an immutable reference vault with CONFIRMED status chips. |
| **7.0** | **Consistency Guardian** | Live text evaluator auditing future copy against locked DNA with line-by-line feedback and intent-preserving rewrites. |
| **7.5** | **Drift Detector** | Detects systemic drift across multi-submission history with strict data honesty rules (requires ≥3 real posts). |

---

## 📦 Features & Interactions

- **Preset Library:** Includes pre-computed, high-fidelity brand profiles:
  - **Kora Health:** Clinical Workload Defense & ICU Nurse Telemetry.
  - **Aetheria:** Autonomous Medical Cold-Chain Air Transit.
- **Custom Brand Intake Wizard:** Input your own startup idea, problem, and audience to generate a full battle-tested system.
- **Brand DNA DAG Simulator:** Click any node (e.g. `personality` or `target_audience`) to edit and watch the engine compute downstream effects and emit real causal diff logs.
- **Live SVG Vector Export:** Download vector logo assets directly in SVG format.
- **1-Click Export:** Download the entire brand book as formatted Markdown (`.md`) or structured JSON (`.json`).
- **Interactive Consistency Guardian:** Type or paste live marketing copy to receive instant alignment scores (1–10) and forensic line-by-line breakdowns.
- **Brand Drift Telemetry:** Multi-submission trend charts tracking voice, positioning, and differentiator adherence over time.

---

## 📄 License
MIT License. Created for the AI Brand Intelligence Engine.
